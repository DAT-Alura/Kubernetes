#!/bin/bash

curl -X POST -H 'Content-type: application/json' --data '{"text":"Subimos um novo pod para sua aplicacao teste"}' https://hooks.slack.com/services/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
