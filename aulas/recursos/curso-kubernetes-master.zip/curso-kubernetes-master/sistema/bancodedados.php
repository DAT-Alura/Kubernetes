<?php

$host = "banco_mysql";
$usuario = "root";
$senha = "q1w2e3r4";
$banco = "empresa";

?>
