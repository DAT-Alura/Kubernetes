<?php
# URL DO SISTEMA DE NOTICIAS
const urlnoticias = 'http://localhost:8587/';
?>
