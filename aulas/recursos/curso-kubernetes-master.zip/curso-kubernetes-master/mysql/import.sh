#!/bin/bash

mysql -u root -pq1w2e3r4 empresa < empresa_noticias.sql

mysql -u root -pq1w2e3r4 empresa < empresa_usuario.sql
